﻿---
title: "Rapport SAÉ 2.03"
author:
  - Othemane KHACHNANE
  - Benjamin LELEU
  - Samuel TURPIN
summary: "Ce rapport présente les étapes et les choix effectués lors de la configuration d'une machine virtuelle Debian 12 pour la SAÉ 2.03."
---



# Préparation de la machine virtuelle :


## Prérequis matériels

![Installation VM](img_rapport/VirtualBox_preinstallation.png)


La configuration matérielle minimale requise pour la machine virtuelle est la suivante :
* 4 Go de RAM
* 20 Go d'espace disque ou plus
* VirtualBox installé
* Iso Debian 12


##  Création de la machine virtuelle


La machine virtuelle a été créée avec les caractéristiques suivantes :
* Nom : sae203
* Dossier : /usr/local/virtual_machine/infoetu/login
* Type : Linux
* Version : Debian 64-bit
* Mémoire vive (RAM) : 2048 Mo
* Disque dur : 20 Go (une seule partition)

![Installation VM](img_rapport\\Vm_istall.png)

###  Installation du système d'exploitation


L'image de l’ISO bootable de Debian 12 qui nous a été fournie a été utilisée pour installer le système d'exploitation. L'installation a été réalisée manuellement.
Vous pouvez trouver l'iso de Debian 12 depuis ce lien : https://www.debian.org/releases/stable/amd64/ch05s01.fr.html

###  Configuration du réseau


Le réseau a été configuré en mode NAT.


###  Choix des logiciels de démarrage


Les logiciels de démarrage suivants ont été sélectionnés :
* Environnement de bureau Debian MATE (décocher Gnome)
* Serveur web
* Serveur ssh
* Utilitaires usuels du système

![Installation Mate](img_rapport/Istaller_mate.PNG)
![Ajout des package](img_rapport/package_add.PNG)

##  Configuration du système :


###  Accès sudo pour l'utilisateur "user"


L'utilisateur "user" a été ajouté au groupe sudo afin de lui permettre d'exécuter des commandes avec les droits root.


###  Installation des suppléments invités


Les suppléments invités ont été installés pour améliorer les performances et la compatibilité de la machine virtuelle avec le système hôte.


##  Questions :


###  Configuration matérielle dans VirtualBox


* 64-bit dans "Debian 64-bit" signifie que le système d'exploitation est capable d'exploiter les architectures 64 bits.
* La configuration réseau par défaut est NAT.
* Le fichier de configuration de la machine virtuelle est un fichier XML nommé "sae203.vbox".
* Il est possible de modifier le fichier de configuration pour ajouter des processeurs à la machine virtuelle, mais il est important de bien connaître la syntaxe XML pour éviter des erreurs.


###  Installation OS de base


* Un fichier iso bootable est un fichier image qui peut être utilisé pour démarrer un ordinateur et installer un système d'exploitation.
* MATE est un environnement de bureau léger et personnalisable basé sur GNOME 2.
* GNOME est un environnement de bureau moderne et riche en fonctionnalités.
* Un serveur web est un logiciel qui permet de diffuser des pages web sur internet.
* Un serveur ssh est un logiciel qui permet de se connecter à un ordinateur distant en toute sécurité.
* Un serveur mandataire est un serveur qui agit comme intermédiaire entre un client et un serveur distant.


###  sudo


La commande `groups user` permet de connaître les groupes auxquels appartient l'utilisateur "user".


###  Suppléments invités


La version du noyau Linux utilisé par la machine virtuelle peut être trouvée en exécutant la commande `uname -r`.
Les suppléments invités permettent d'améliorer les performances et la compatibilité de la machine virtuelle avec le système hôte. Deux raisons principales de les installer sont :
* Améliorer la gestion de la souris et du clavier
* Permettre le partage de fichiers et de dossiers entre la machine virtuelle et le système hôte
La commande `mount` permet de monter un système de fichiers sur un point de montage.


##  Gitk et Git-gui :

![Lancement Gitk](img_rapport/gitsae2.03.png)

###  Qu'est-ce que Gitk ?


Gitk est un visualiseur d'historique graphique pour les dépôts Git. Il permet de naviguer dans l'historique du projet, de visualiser les commits, les branches et les modifications apportées aux fichiers. C'est un outil précieux pour comprendre l'évolution du projet et pour identifier les commits spécifiques à examiner.

Documentation de Gitk : ***https://git-scm.com/docs/gitk***

###  Comment se lance Gitk ?


Gitk peut être lancé depuis le terminal en tapant la commande `gitk`. Il est également possible de le lancer depuis le menu d'applications de votre distribution Linux.


###  Qu'est-ce que Git-gui ?


Git-gui est un outil de création de commits graphiques. Il permet de créer des commits en sélectionnant les fichiers modifiés et en ajoutant un message de commit. Il offre également des options pour annuler les modifications, créer des branches et fusionner des branches.

Documentation Git-gui: ***https://git-scm.com/docs/git-gui***

###  Comment se lance Git-gui ?


Git-gui peut être lancé depuis le terminal en tapant la commande `git-gui`. Il est également possible de le lancer depuis le menu d'applications de votre distribution Linux.


##  GitKraken :


###  Pourquoi avoir choisi GitKraken ?


* GitKraken a été choisi car il s'agit d'une interface graphique intuitive et agréable à utiliser.

* Site web de GitKraken: ***https://www.gitkraken.com/***

### Installation de GitKraken


GitKraken peut être installé sur Debian en suivant les étapes suivantes :
1. Télécharger le fichier d'installation depuis le site web de GitKraken : ***[https://release.gitkraken.com/linux/gitkraken-amd64.deb](https://release.gitkraken.com/linux/gitkraken-amd64.deb)*** 
2. Installer le fichier d'installation avec la commande suivante :

## Installation Gitea :

### Téléchargement du binaire

  1. Rendez-vous sur la page de téléchargement de Gitea : ***https://www.linguee.fr/francais-anglais/traduction/non+valide.html***
  2. Choisissez la version la plus récente de Gitea.
  3. Téléchargez le binaire correspondant à votre architecture (amd64, arm64, etc.).

###  Installation du binaire

  1. Déplacez le fichier binaire téléchargé vers le répertoire /usr/local/bin.

    sudo mv gitea-1.21.7-linux-amd64 /usr/local/bin/gitea

  1. Modifiez les permissions du fichier binaire pour le rendre exécutable.
    ***sudo chmod +x /usr/local/bin/gitea***

###  Création du compte utilisateur Gitea

  Créez un utilisateur système dédié à Gitea.
    sudo adduser --system --home /var/lib/gitea --shell /bin/bash gitea

###  Initialisation de la base de données

Gitea peut utiliser différentes bases de données, comme SQLite3, MySQL ou PostgreSQL. Dans ce guide, nous utiliserons SQLite3 pour sa simplicité.

  1. Créez le répertoire de données de Gitea.

    sudo mkdir -p /var/lib/gitea/data

  2. Initialisez la base de données SQLite3.

    sudo gitea --config /etc/gitea/app.ini init --db-type sqlite3

###  Configuration de Gitea

  1. Copiez le fichier de configuration par défaut.

    sudo cp /usr/local/share/gitea/app.ini /etc/gitea/app.ini

  2. Modifiez le fichier de configuration /etc/gitea/app.ini pour personnaliser votre installation.

  3. Vérifiez votre version avec la commande :
        Gitea --version

![Gitea Version](img_rapport/gitea_version.png)

###  Démarrage de Gitea

Démarrez le service Gitea.

***sudo systemctl start gitea***

![gitea interface](img_rapport/gitea-create-token-user-menu.png)

###  Accès à l'interface web de Gitea

Ouvrez votre navigateur web et accédez à l'adresse suivante :

***http://localhost:3000***

Vous devriez voir l'interface web de Gitea. Suivez les instructions à l'écran pour créer un compte administrateur et configurer votre instance Gitea.

**Remarques**

  *  Assurez-vous de consulter la documentation officielle de Gitea pour obtenir des informations plus détaillées sur l'installation et la configuration : https://www.linguee.fr/francais-anglais/traduction/non+valide.html

**Gitea help**

    Forum de la communauté Gitea: https://www.linguee.fr/francais-anglais/traduction/non+valide.html