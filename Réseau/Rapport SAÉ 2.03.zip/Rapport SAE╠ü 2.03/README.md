---
title: "README SAÉ 2.03"
author:
  - Othemane KHACHNANE
  - Benjamin LELEU
  - Samuel TURPIN
summary: "Ce README explique comment compiler le rapport de SAÉ fait en MarkDown"
---

## Comment compiler le rapport

**Prérequis:**

* Pandoc (ou un autre outil de compilation de Markdown)
* Visual Studio Code (optionnel)
* Extension Markdown Preview Plus pour Visual Studio Code (optionnel)

**Étapes:**

1. **Téléchargez le rapport Markdown:**

    * Téléchargez le fichier `sources.md` depuis le dépôt.

2. **Compilez le rapport:**

    * **Méthode 1: Pandoc**

        * Ouvrez une invite de commande et accédez au dossier où le fichier `sources.md` a été téléchargé.
        * Exécutez la commande suivante pour générer le fichier HTML:

        ```
        pandoc -s -c style.css sources.md -o output.html
        ```

        * Exécutez la commande suivante pour générer le fichier PDF:

        ```
        pandoc sources.md -N --toc -o rapport.pdf
        ```

    * **Méthode 2: Visual Studio Code**

        * Ouvrez le fichier `sources.md` dans Visual Studio Code.
        * Cliquez sur l'icône "Prévisualiser" dans la barre d'état.
        * Sélectionnez le format de sortie (HTML ou PDF) dans le menu déroulant.

3. **Consultez le rapport:**

    * Ouvrez le fichier HTML ou PDF généré pour consulter votre rapport.

**Résolution des problèmes courants:**

* Si vous rencontrez des problèmes pour générer le rapport, assurez-vous que vous avez bien installé tous les prérequis.
* Si le style CSS ne s'applique pas correctement, assurez-vous que le fichier `style.css` est dans le même répertoire que votre fichier `sources.md`.
* Si vous rencontrez des erreurs lors de la compilation avec Pandoc, consultez la documentation de Pandoc pour obtenir de l'aide.

**Documentation de Pandoc: https://pandoc.org/MANUAL.html**